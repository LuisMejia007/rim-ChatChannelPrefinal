//
//  CreateChannelCell.swift
//  Rim
//
//  Created by Chatan Konda on 10/2/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit

class CreateChannelCell: UITableViewCell {

    
    //@IBOutlet weak var newChannelTextField: UITextField!
    
    @IBOutlet weak var newChannelNameField: UITextField!


    @IBOutlet weak var createChannelButton: UIButton!


}
